package com.pradeep.jobms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
